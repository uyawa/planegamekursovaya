// PlaneGame.cpp : Defines the entry point for the application.
//

#include "framework.h"
#include "resource.h"
#include "PlaneGame.h"
#include <vector>

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.

    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_PLANEGAME, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_PLANEGAME));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PLANEGAME));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+3);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}
HWND hWnd;
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, 1200, 800, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}



RECT fieldSize;

int planeSize = 50;
int AsteroidSize = 48;
int posX = 200;
int posY = 300;
int dash = 15;
int maxAsteroidSpeed = 10;
int minAsteroidSpeed = 4;
int asteroidCount = 15;
int LifeCount = 1;
int HeartSize = 16;
int NeedToColision = 15;

HDC hdcStone;
HDC hdcPlane;
HDC hdcHeart;
HBITMAP BitmapHeart;

class Object
{
public:
    float x, y, SpeedX, SpeedY;
    Object(float x, float y) :
        x(x), y(y) {
        SpeedY = (rand() % maxAsteroidSpeed * 2) - maxAsteroidSpeed;
        SpeedX = (rand() % maxAsteroidSpeed * 2) - maxAsteroidSpeed;
    }

    void update()
    {
        x += SpeedX;
        y += SpeedY;

        if (x > fieldSize.right) x = 0;  
        if (x < 0) x = fieldSize.right;

        if (y < 0) {
            y = fieldSize.bottom;
            if (SpeedY < maxAsteroidSpeed)
            {
                SpeedY -= 0.5;
            }
        }
        if (y > fieldSize.bottom)
        {
            y = 0;
            if (SpeedY < maxAsteroidSpeed)
            {
                SpeedY += 0.5;
            }
        }
    }
};

std::vector<Object*> Asteroids;

void GameOver() {
    KillTimer(hWnd, 100);
    MessageBox(hWnd, L"���� ��������", L"�����������", MB_OK);
}

void Colision() {
    for (int i = 0; i < Asteroids.size(); i++)
    {
        if ((Asteroids[i]->x + AsteroidSize > posX + NeedToColision && Asteroids[i]->x + AsteroidSize < posX + planeSize) // �������� �����
            || (posX + planeSize - NeedToColision > Asteroids[i]->x && Asteroids[i]->x > posX )) {
            if ((Asteroids[i]->y < posY + NeedToColision && posY + NeedToColision < Asteroids[i]->y + AsteroidSize) // �����
                || (Asteroids[i]->y < posY + planeSize + NeedToColision && posY + planeSize < Asteroids[i]->y + AsteroidSize - NeedToColision)) // �������
            {
                LifeCount--;
                break;
            }
        }
    }
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {
        HBITMAP BitmapStone = LoadBitmap(hInst, MAKEINTRESOURCEW(Stone));
        HBITMAP BitmapPlane = LoadBitmap(hInst, MAKEINTRESOURCEW(Plane));
        BitmapHeart = LoadBitmap(hInst, MAKEINTRESOURCEW(Heart));

        HDC hdc = GetDC(hWnd);
        hdcStone = CreateCompatibleDC(hdc);
        hdcPlane = CreateCompatibleDC(hdc);
        hdcHeart = CreateCompatibleDC(hdc);
        SelectObject(hdcStone, BitmapStone);
        SelectObject(hdcPlane, BitmapPlane);
        SelectObject(hdcHeart, BitmapHeart);
        ReleaseDC(hWnd, hdc);

        GetClientRect(hWnd, &fieldSize);
        for (int i = 0; i < asteroidCount; i++)
        {
            Object* temp = new Object(rand() % fieldSize.right, fieldSize.bottom);
            Asteroids.push_back(temp);
        }
        SetTimer(hWnd, 100, 100, NULL);
        break;
    }
    case WM_TIMER:
    {
      
        for (int i = 0; i < Asteroids.size(); i++)
        {
            Asteroids[i]->update();
        }
        Colision();
        if (LifeCount == 0)
        {
            GameOver();
        }
        InvalidateRect(hWnd, NULL, true);
        break;
    }
    case WM_KEYDOWN: {
        switch (wParam)
        {
        case VK_RIGHT: {
            if (posX < fieldSize.right - planeSize - dash)
            {
                posX += dash;
            }
            else
            {
                posX = 0;
            }
            break;
        }
        case VK_LEFT: {
            if (posX > dash)
            {
                posX -= dash;
            }
            else {
                posX = fieldSize.right - planeSize - 1;
            }
            break;
        }
        default:
            break;
        }

        break;
    }
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Parse the menu selections:
            switch (wmId)
            {
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            HBRUSH HeartBrush = CreatePatternBrush(BitmapHeart);
            StretchBlt(hdc, posX, posY,
                planeSize,
                planeSize, hdcPlane,
                0, 0, planeSize, planeSize, SRCCOPY);
            for (int i = 0; i < Asteroids.size(); i++)
            {

                StretchBlt(hdc, Asteroids[i]->x, Asteroids[i]->y,
                    AsteroidSize,
                    AsteroidSize, hdcStone,
                    0, 0, AsteroidSize, AsteroidSize, SRCCOPY);
            }
            SelectObject(hdc, HeartBrush);
            for (int i = 0; i < LifeCount; i++)
            {
                Rectangle(hdc, HeartSize * i, 0, HeartSize * i + HeartSize, HeartSize);
            }
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
